from flask import Blueprint, jsonify
import json
import os

categories_bp = Blueprint('categories', __name__)

@categories_bp.route('/categories', methods=['GET'])
def get_cid10_categories():
    """Retorna as categorias principais do CID-10."""
    categories = [
        {
            "code": "A00-B99",
            "title": "Algumas doenças infecciosas e parasitárias",
            "description": "Inclui doenças causadas por vírus, bactérias, fungos e parasitas"
        },
        {
            "code": "C00-D48",
            "title": "Neoplasias",
            "description": "Tumores benignos e malignos, incluindo cânceres"
        },
        {
            "code": "D50-D89",
            "title": "Doenças do sangue e dos órgãos hematopoéticos",
            "description": "Anemias, distúrbios de coagulação e doenças do sistema imunológico"
        },
        {
            "code": "E00-E90",
            "title": "Doenças endócrinas, nutricionais e metabólicas",
            "description": "Diabetes, distúrbios da tireoide, obesidade e desnutrição"
        },
        {
            "code": "F00-F99",
            "title": "Transtornos mentais e comportamentais",
            "description": "Depressão, ansiedade, esquizofrenia e transtornos relacionados ao uso de substâncias"
        },
        {
            "code": "G00-G99",
            "title": "Doenças do sistema nervoso",
            "description": "Epilepsia, Parkinson, Alzheimer e outras doenças neurológicas"
        },
        {
            "code": "H00-H59",
            "title": "Doenças do olho e anexos",
            "description": "Catarata, glaucoma, conjuntivite e outros problemas oculares"
        },
        {
            "code": "H60-H95",
            "title": "Doenças do ouvido e da apófise mastoide",
            "description": "Otite, perda auditiva e outros problemas do ouvido"
        },
        {
            "code": "I00-I99",
            "title": "Doenças do aparelho circulatório",
            "description": "Hipertensão, infarto, AVC e outras doenças cardiovasculares"
        },
        {
            "code": "J00-J99",
            "title": "Doenças do aparelho respiratório",
            "description": "Pneumonia, asma, DPOC e outras doenças pulmonares"
        },
        {
            "code": "K00-K93",
            "title": "Doenças do aparelho digestivo",
            "description": "Gastrite, úlceras, hepatite e outras doenças do sistema digestivo"
        },
        {
            "code": "L00-L99",
            "title": "Doenças da pele e do tecido subcutâneo",
            "description": "Dermatite, psoríase, infecções de pele e outras doenças dermatológicas"
        },
        {
            "code": "M00-M99",
            "title": "Doenças do sistema osteomuscular",
            "description": "Artrite, artrose, osteoporose e outras doenças dos ossos e músculos"
        },
        {
            "code": "N00-N99",
            "title": "Doenças do aparelho geniturinário",
            "description": "Infecções urinárias, insuficiência renal e doenças dos órgãos reprodutivos"
        },
        {
            "code": "O00-O99",
            "title": "Gravidez, parto e puerpério",
            "description": "Complicações da gravidez, parto e período pós-parto"
        },
        {
            "code": "P00-P96",
            "title": "Algumas afecções originadas no período perinatal",
            "description": "Problemas que afetam recém-nascidos"
        },
        {
            "code": "Q00-Q99",
            "title": "Malformações congênitas",
            "description": "Defeitos de nascimento e anomalias cromossômicas"
        },
        {
            "code": "R00-R99",
            "title": "Sintomas, sinais e achados anormais",
            "description": "Sintomas não classificados em outras categorias"
        },
        {
            "code": "S00-T98",
            "title": "Lesões, envenenamento e outras causas externas",
            "description": "Fraturas, queimaduras, intoxicações e traumatismos"
        },
        {
            "code": "V01-Y98",
            "title": "Causas externas de morbidade e mortalidade",
            "description": "Acidentes, violência e outras causas externas"
        },
        {
            "code": "Z00-Z99",
            "title": "Fatores que influenciam o estado de saúde",
            "description": "Consultas preventivas, vacinação e outros contatos com serviços de saúde"
        }
    ]
    
    return jsonify({
        'categories': categories,
        'total': len(categories)
    })

@categories_bp.route('/categories/<category_code>', methods=['GET'])
def get_category_diseases(category_code):
    """Retorna doenças de uma categoria específica."""
    # Carregar dados CID-10
    cid10_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'cid10_datasus.json')
    if os.path.exists(cid10_path):
        with open(cid10_path, 'r', encoding='utf-8') as f:
            cid10_data = json.load(f)
    else:
        return jsonify({'error': 'Base de dados não encontrada'}), 404
    
    # Extrair faixa de códigos da categoria
    if '-' in category_code:
        start_code, end_code = category_code.split('-')
        start_letter = start_code[0]
        end_letter = end_code[0]
        
        # Filtrar doenças da categoria
        category_diseases = []
        for disease in cid10_data:
            code = disease.get('code', '')
            if code and code[0] >= start_letter and code[0] <= end_letter:
                category_diseases.append(disease)
        
        return jsonify({
            'category_code': category_code,
            'diseases': category_diseases[:50],  # Limitar a 50 resultados
            'total': len(category_diseases)
        })
    
    return jsonify({'error': 'Código de categoria inválido'}), 400

