from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

class Disease(db.Model):
    __tablename__ = 'diseases'
    
    id = db.Column(db.Integer, primary_key=True)
    codigo = db.Column(db.String(10), unique=True, nullable=False)
    nome = db.Column(db.String(500), nullable=False)
    categoria = db.Column(db.String(1), nullable=False)
    tem_tratamento = db.Column(db.Boolean, default=True)
    incapacitante = db.Column(db.Boolean, default=False)
    tipo_tratamento = db.Column(db.String(100))
    gravidade = db.Column(db.String(50))
    prognostico = db.Column(db.String(200))
    
    def to_dict(self):
        return {
            'id': self.id,
            'codigo': self.codigo,
            'nome': self.nome,
            'categoria': self.categoria,
            'tem_tratamento': self.tem_tratamento,
            'incapacitante': self.incapacitante,
            'tipo_tratamento': self.tipo_tratamento,
            'gravidade': self.gravidade,
            'prognostico': self.prognostico
        }

