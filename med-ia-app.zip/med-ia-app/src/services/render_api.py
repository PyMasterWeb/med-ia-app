import requests
import os

class RenderAPI:
    def __init__(self):
        self.client_id = os.environ.get('RENDER_CLIENT_ID', '84b64ed5-c3b1-47d1-a230-5a8234ed6a09_3cc45ea9-bba3-4857-8098-df9277fed4e0')
        self.client_secret = os.environ.get('RENDER_CLIENT_SECRET', 'cSAbaw4dlFaGxBceLnnAvo6nHZLtTC3unArNaz8GCA4=')
        self.api_key = os.environ.get('RENDER_API_KEY', 'rnd_MXAQGe8GLrsBKdKvqzxkYFOxWShO')
        self.base_url = 'https://api.render.com/v1'
        self.headers = {
            'Authorization': f'Bearer {self.api_key}',
            'Content-Type': 'application/json'
        }

    def get_medical_data(self, disease_code):
        """Busca dados médicos para um código de doença específico."""
        try:
            # Endpoint hipotético da API Render para dados médicos
            url = f"{self.base_url}/medical/diseases/{disease_code}"
            response = requests.get(url, headers=self.headers)
            
            if response.status_code == 200:
                return response.json()
            elif response.status_code == 404:
                return None
            else:
                response.raise_for_status()
                
        except requests.exceptions.RequestException as e:
            print(f"Erro ao acessar API Render: {e}")
            return None

    def get_medication_data(self, disease_code):
        """Busca dados de medicamentos para uma doença específica."""
        try:
            url = f"{self.base_url}/medical/medications/{disease_code}"
            response = requests.get(url, headers=self.headers)
            
            if response.status_code == 200:
                return response.json()
            elif response.status_code == 404:
                return None
            else:
                response.raise_for_status()
                
        except requests.exceptions.RequestException as e:
            print(f"Erro ao acessar dados de medicamentos: {e}")
            return None

    def get_symptoms_data(self, disease_code):
        """Busca dados de sintomas para uma doença específica."""
        try:
            url = f"{self.base_url}/medical/symptoms/{disease_code}"
            response = requests.get(url, headers=self.headers)
            
            if response.status_code == 200:
                return response.json()
            elif response.status_code == 404:
                return None
            else:
                response.raise_for_status()
                
        except requests.exceptions.RequestException as e:
            print(f"Erro ao acessar dados de sintomas: {e}")
            return None

    def get_therapy_data(self, disease_code, therapy_type='medication'):
        """Busca dados de terapia para uma doença específica."""
        try:
            url = f"{self.base_url}/medical/therapy/{therapy_type}/{disease_code}"
            response = requests.get(url, headers=self.headers)
            
            if response.status_code == 200:
                return response.json()
            elif response.status_code == 404:
                return None
            else:
                response.raise_for_status()
                
        except requests.exceptions.RequestException as e:
            print(f"Erro ao acessar dados de terapia: {e}")
            return None

    def search_diseases(self, query):
        """Busca doenças na API Render."""
        try:
            url = f"{self.base_url}/medical/search"
            params = {'q': query, 'limit': 10}
            response = requests.get(url, headers=self.headers, params=params)
            
            if response.status_code == 200:
                return response.json()
            elif response.status_code == 404:
                return []
            else:
                response.raise_for_status()
                
        except requests.exceptions.RequestException as e:
            print(f"Erro ao buscar doenças na API Render: {e}")
            return []

    def validate_connection(self):
        """Valida a conexão com a API Render."""
        try:
            url = f"{self.base_url}/health"
            response = requests.get(url, headers=self.headers, timeout=10)
            return response.status_code == 200
        except requests.exceptions.RequestException:
            return False

