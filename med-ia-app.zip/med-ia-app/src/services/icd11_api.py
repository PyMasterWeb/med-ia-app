import requests

class ICD11API:
    def __init__(self):
        self.base_url = "https://id.who.int/icd/entity"
        self.headers = {
            "Accept": "application/json",
            "Accept-Language": "pt-BR",
            "API-Version": "v2"
        }

    def search_diseases(self, query):
        search_url = f"{self.base_url}/search?q={query}"
        response = requests.get(search_url, headers=self.headers)
        response.raise_for_status()
        data = response.json()
        
        results = []
        for entity in data.get("destinationEntities", [])[:5]: # Limitar a 5 resultados para relevância
            results.append({
                "cid_code": entity.get("code", "N/A"),
                "name": entity.get("title", {}).get("" if self.headers["Accept-Language"] == "en" else self.headers["Accept-Language"], "N/A"),
                "definition": entity.get("definition", {}).get("" if self.headers["Accept-Language"] == "en" else self.headers["Accept-Language"], "N/A")
            })
        return results

    def get_entity_details(self, entity_id):
        entity_url = f"{self.base_url}/{entity_id}"
        response = requests.get(entity_url, headers=self.headers)
        response.raise_for_status()
        data = response.json()
        return data


