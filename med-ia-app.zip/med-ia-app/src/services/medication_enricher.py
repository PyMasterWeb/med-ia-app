
import pandas as pd

class MedicationEnricher:
    def __init__(self, csv_path):
        self.medications_df = pd.read_csv(csv_path, sep=";", encoding="ISO-8859-1", low_memory=False)
        # Tratar valores ausentes nas colunas relevantes
        self.medications_df["PRINCIPIO_ATIVO"] = self.medications_df["PRINCIPIO_ATIVO"].fillna("")
        self.medications_df["NOME_COMERCIAL"] = self.medications_df["NOME_COMERCIAL"].fillna("")

    def enrich_disease_with_medications(self, disease):
        disease_name = disease.get("nome", "").lower()
        medications = self.get_medications_for_disease(disease_name)
        disease["medications"] = medications
        return disease

    def get_medications_for_disease(self, disease_name):
        # Lógica para encontrar medicamentos baseada no nome da doença
        # Esta é uma implementação simplificada e pode ser melhorada
        disease_keywords = disease_name.split()
        
        # Filtrar medicamentos que contenham qualquer uma das palavras-chave da doença
        # no nome do princípio ativo ou nome comercial
        filtered_meds = self.medications_df[self.medications_df.apply(
            lambda row: any(keyword in row["PRINCIPIO_ATIVO"].lower() or keyword in row["NOME_COMERCIAL"].lower() for keyword in disease_keywords),
            axis=1
        )]
        
        # Limitar a 5 medicamentos para não sobrecarregar a interface
        top_meds = filtered_meds.head(5)
        
        med_list = []
        for _, row in top_meds.iterrows():
            med_list.append({
                "principio_ativo": row["PRINCIPIO_ATIVO"],
                "nomes_comerciais": [row["NOME_COMERCIAL"]],
                "dosagem_usual": "Consultar bula",
                "via_administracao": row["FORMA_FARMACEUTICA"]
            })
        return med_list


