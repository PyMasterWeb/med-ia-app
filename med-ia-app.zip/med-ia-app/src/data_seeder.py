from src.models.disease import db, Disease

def seed_all():
    """Popula o banco de dados com dados iniciais."""
    
    # Dados de exemplo de doenças CID-10
    diseases_data = [
        {
            'codigo': 'A01.0',
            'nome': 'Febre tifóide',
            'categoria': 'A',
            'tem_tratamento': True,
            'incapacitante': False,
            'tipo_tratamento': 'Medicamentoso',
            'gravidade': 'Grave',
            'prognostico': 'Bom com tratamento adequado'
        },
        {
            'codigo': 'A01.1',
            'nome': 'Febre paratifóide A',
            'categoria': 'A',
            'tem_tratamento': True,
            'incapacitante': False,
            'tipo_tratamento': 'Medicamentoso',
            'gravidade': 'Moderada',
            'prognostico': 'Bom com tratamento adequado'
        },
        {
            'codigo': 'I10',
            'nome': 'Hipertensão essencial',
            'categoria': 'I',
            'tem_tratamento': True,
            'incapacitante': False,
            'tipo_tratamento': 'Medicamentoso',
            'gravidade': 'Moderada',
            'prognostico': 'Controlável com tratamento'
        },
        {
            'codigo': 'E11',
            'nome': 'Diabetes mellitus não-insulino-dependente',
            'categoria': 'E',
            'tem_tratamento': True,
            'incapacitante': False,
            'tipo_tratamento': 'Medicamentoso',
            'gravidade': 'Moderada',
            'prognostico': 'Controlável com tratamento'
        },
        {
            'codigo': 'J44',
            'nome': 'Outras doenças pulmonares obstrutivas crônicas',
            'categoria': 'J',
            'tem_tratamento': True,
            'incapacitante': True,
            'tipo_tratamento': 'Medicamentoso',
            'gravidade': 'Grave',
            'prognostico': 'Variável conforme tratamento'
        },
        {
            'codigo': 'K29',
            'nome': 'Gastrite e duodenite',
            'categoria': 'K',
            'tem_tratamento': True,
            'incapacitante': False,
            'tipo_tratamento': 'Medicamentoso',
            'gravidade': 'Leve',
            'prognostico': 'Bom com tratamento adequado'
        },
        {
            'codigo': 'F32',
            'nome': 'Episódios depressivos',
            'categoria': 'F',
            'tem_tratamento': True,
            'incapacitante': True,
            'tipo_tratamento': 'Psicológico',
            'gravidade': 'Moderada',
            'prognostico': 'Bom com tratamento adequado'
        },
        {
            'codigo': 'F41',
            'nome': 'Outros transtornos ansiosos',
            'categoria': 'F',
            'tem_tratamento': True,
            'incapacitante': False,
            'tipo_tratamento': 'Psicológico',
            'gravidade': 'Leve',
            'prognostico': 'Bom com tratamento adequado'
        }
    ]
    
    # Inserir doenças no banco
    for disease_data in diseases_data:
        existing_disease = Disease.query.filter_by(codigo=disease_data['codigo']).first()
        if not existing_disease:
            disease = Disease(**disease_data)
            db.session.add(disease)
    
    db.session.commit()
    print(f"Banco de dados populado com {len(diseases_data)} doenças.")

