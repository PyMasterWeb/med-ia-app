from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from src.models.user import db

class Disease(db.Model):
    __tablename__ = 'diseases'
    
    id = db.Column(db.Integer, primary_key=True)
    cid_code = db.Column(db.String(10), nullable=False, unique=True, index=True)
    name = db.Column(db.String(500), nullable=False, index=True)
    treatment_info = db.Column(db.Text)  # Informações gerais sobre tratamento
    incapacitating_potential = db.Column(db.String(20), default='não')  # 'não', 'potencialmente', 'sim'
    recommended_treatment = db.Column(db.Text)  # Qual o tratamento mais indicado
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<Disease {self.cid_code}: {self.name}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'cid_code': self.cid_code,
            'name': self.name,
            'treatment_info': self.treatment_info,
            'incapacitating_potential': self.incapacitating_potential,
            'recommended_treatment': self.recommended_treatment,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

