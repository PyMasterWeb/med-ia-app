from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from src.models.user import db

class HealthFacility(db.Model):
    __tablename__ = 'health_facilities'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False, index=True)
    type = db.Column(db.String(50), nullable=False)  # 'posto de saúde', 'hospital', 'upa', 'pronto socorro'
    address = db.Column(db.String(500))
    latitude = db.Column(db.Float)
    longitude = db.Column(db.Float)
    phone = db.Column(db.String(20))
    services = db.Column(db.Text)  # Serviços oferecidos
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<HealthFacility {self.name}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'type': self.type,
            'address': self.address,
            'latitude': self.latitude,
            'longitude': self.longitude,
            'phone': self.phone,
            'services': self.services,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }
    
    def distance_to(self, lat, lon):
        """Calcula a distância aproximada em km usando a fórmula de Haversine simplificada"""
        import math
        
        if not self.latitude or not self.longitude:
            return float('inf')
        
        # Conversão para radianos
        lat1, lon1 = math.radians(self.latitude), math.radians(self.longitude)
        lat2, lon2 = math.radians(lat), math.radians(lon)
        
        # Diferenças
        dlat = lat2 - lat1
        dlon = lon2 - lon1
        
        # Fórmula de Haversine
        a = math.sin(dlat/2)**2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon/2)**2
        c = 2 * math.asin(math.sqrt(a))
        
        # Raio da Terra em km
        r = 6371
        
        return c * r

