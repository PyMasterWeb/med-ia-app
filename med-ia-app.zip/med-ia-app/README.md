# MED.IA - Consulta Médica Inteligente

Sistema de consulta médica inteligente baseado no CID-10 com funcionalidades avançadas de diagnóstico e tratamento.

## Funcionalidades

### ✅ Implementadas
- **Busca de Doenças**: Busca por código CID ou nome da doença
- **Sintomas**: Visualização de sintomas para cada doença
- **Terapia Medicamentosa**: Informações sobre medicamentos para tratamento
- **Terapia Não-Medicamentosa**: Tratamentos alternativos e complementares
- **Diagnóstico**: Informações detalhadas sobre diagnóstico da doença
- **Interações Medicamentosas**: Verificação de interações entre medicamentos
- **Categorias CID-10**: Navegação por categorias do CID-10
- **Diagnóstico por Laudo**: Análise de laudos médicos para sugestão de diagnóstico

### 🔧 Tecnologias Utilizadas
- **Backend**: Flask, SQLAlchemy, Flask-CORS
- **Frontend**: HTML5, CSS3, JavaScript (Vanilla)
- **Banco de Dados**: SQLite
- **APIs**: Integração com API Render, CID-11 (WHO)

## Estrutura do Projeto

```
MED.IA/
├── main.py                 # Arquivo principal da aplicação
├── requirements.txt        # Dependências Python
├── static/
│   └── index.html         # Interface do usuário
├── src/
│   ├── models/
│   │   └── disease.py     # Modelo de dados das doenças
│   ├── routes/
│   │   └── disease.py     # Rotas da API
│   ├── services/
│   │   ├── icd11_api.py           # Integração com API CID-11
│   │   ├── medication_enricher.py # Enriquecimento com medicamentos
│   │   ├── drug_interaction_checker.py # Verificação de interações
│   │   └── render_api.py          # Integração com API Render
│   └── data_seeder.py     # Populador de dados iniciais
└── README.md
```

## Instalação e Execução

### Pré-requisitos
- Python 3.11+
- pip

### Passos para Instalação

1. Clone o repositório:
```bash
git clone https://github.com/PyMasterWeb/med-ia-app.git
cd med-ia-app
```

2. Instale as dependências:
```bash
pip install -r requirements.txt
```

3. Configure as variáveis de ambiente (opcional):
```bash
export RENDER_CLIENT_ID="seu_client_id"
export RENDER_CLIENT_SECRET="seu_client_secret"
export RENDER_API_KEY="sua_api_key"
```

4. Execute a aplicação:
```bash
python main.py
```

5. Acesse no navegador:
```
http://localhost:5000
```

## API Endpoints

### Busca de Doenças
- `POST /api/search` - Busca doenças por código CID ou nome

### Informações Específicas
- `GET /api/symptoms/<cid_code>` - Sintomas da doença
- `GET /api/medication_therapy/<cid_code>` - Terapia medicamentosa
- `GET /api/non_medication_therapy/<cid_code>` - Terapia não-medicamentosa
- `GET /api/diagnosis_info/<cid_code>` - Informações de diagnóstico

### Funcionalidades Auxiliares
- `GET /api/categories` - Categorias CID-10
- `POST /api/interactions` - Verificação de interações medicamentosas
- `POST /api/diagnose` - Diagnóstico por laudo médico
- `GET /api/health` - Status da API

## Integração com APIs Externas

### API Render
O sistema integra com a API Render para obter dados médicos atualizados:
- ClientId: Configurado via variável de ambiente
- ClientSecret: Configurado via variável de ambiente  
- API Key: Configurado via variável de ambiente

### API CID-11 (WHO)
Integração com a API oficial da Organização Mundial da Saúde para dados do CID-11.

## Contribuição

1. Faça um fork do projeto
2. Crie uma branch para sua feature (`git checkout -b feature/AmazingFeature`)
3. Commit suas mudanças (`git commit -m 'Add some AmazingFeature'`)
4. Push para a branch (`git push origin feature/AmazingFeature`)
5. Abra um Pull Request

## Licença

Este projeto está sob a licença MIT. Veja o arquivo `LICENSE` para mais detalhes.

## Contato

- **Desenvolvedor**: PyMasterWeb
- **Email**: eletrolucam@gmail.com
- **GitHub**: https://github.com/PyMasterWeb

## Changelog

### v2.0.0 - Funcionalidades Avançadas
- ✅ Adicionado botão "Sintomas" com modal informativo
- ✅ Adicionado botão "Terapia Medicamentosa" com dados de medicamentos
- ✅ Adicionado botão "Terapia Não-Medicamentosa" com tratamentos alternativos
- ✅ Adicionado botão "Diagnóstico" com informações detalhadas
- ✅ Integração com API Render para dados médicos
- ✅ Melhorias na interface do usuário
- ✅ Sistema de modais para exibição de informações detalhadas

### v1.0.0 - Versão Inicial
- Busca básica de doenças por CID-10
- Interface web responsiva
- Integração com banco de dados SQLite

