    print("Populando medicamentos da ANVISA...")
    
    csv_path = os.path.join(os.path.dirname(__file__), 'anvisa_medicamentos_utf8.csv')
    
    if not os.path.exists(csv_path):
        print(f"Arquivo CSV não encontrado: {csv_path}")
        return
    
    count = 0
    with open(csv_path, 'r', encoding='utf-8') as file:
        reader = csv.DictReader(file, delimiter=';')
        
        for row in reader:
            # Verificar se o medicamento já existe
            nome_produto = row.get('NOME_PRODUTO', '').strip().strip('"')
            principio_ativo = row.get('PRINCIPIO_ATIVO', '').strip().strip('"')
            
            if not nome_produto or not principio_ativo:
                continue
            
            existing = Medication.query.filter_by(
                nome_comercial=nome_produto,
                principio_ativo=principio_ativo
            ).first()
            
            if existing:
                continue
            
            # Simular dosagem e instruções baseadas na categoria
            categoria = row.get('CLASSE_TERAPEUTICA', '').strip().strip('"')
            dosagem = generate_dosage(categoria)
            instrucoes = generate_instructions(categoria)
            
            medication = Medication(
                nome_comercial=nome_produto,
                principio_ativo=principio_ativo,
                laboratorio=row.get('EMPRESA_DETENTORA_REGISTRO', '').strip().strip('"'),
                categoria=categoria,
                registro_anvisa=row.get('NUMERO_REGISTRO_PRODUTO', '').strip().strip('"'),
                forma_farmaceutica=row.get('CATEGORIA_REGULATORIA', '').strip().strip('"'),
                dosagem=dosagem,
                instrucoes=instrucoes
            )
            
            db.session.add(medication)
            count += 1
            
            # Commit em lotes para melhor performance
            if count % 100 == 0:
                db.session.commit()
                print(f"Processados {count} medicamentos...")
                
            # Limitar para não sobrecarregar (apenas para demonstração)
            if count >= 1000:
                break
    
    db.session.commit()
    print(f"Total de medicamentos adicionados: {count}")

def generate_dosage(categoria):
    """Gera dosagem simulada baseada na categoria do medicamento"""
    dosage_patterns = {
        'Analgésico': ['500mg a cada 6 horas', '1 comprimido a cada 8 horas', '2 comprimidos até 3x ao dia'],
        'Antibiótico': ['500mg a cada 12 horas por 7 dias', '1 comprimido a cada 8 horas por 10 dias'],
        'Anti-hipertensivo': ['1 comprimido ao dia pela manhã', '5mg uma vez ao dia'],
        'Antidepressivo': ['1 comprimido ao dia', '50mg uma vez ao dia pela manhã'],
        'Anti-inflamatório': ['1 comprimido a cada 12 horas', '20mg a cada 8 horas'],
        'Diurético': ['1 comprimido pela manhã', '25mg uma vez ao dia'],
        'Antidiabético': ['1 comprimido antes das refeições', '500mg 2x ao dia'],
        'Broncodilatador': ['2 inalações a cada 6 horas', '1 inalação quando necessário'],
        'Anticonvulsivante': ['1 comprimido a cada 12 horas', '100mg 2x ao dia'],
        'Ansiolítico': ['1 comprimido quando necessário', '0,5mg até 3x ao dia']
    }
    
    for key in dosage_patterns:
        if key.lower() in categoria.lower():
            return random.choice(dosage_patterns[key])
    
    return '1 comprimido conforme orientação médica'

def generate_instructions(categoria):
    """Gera instruções simuladas baseadas na categoria do medicamento"""
    instruction_patterns = {
        'Analgésico': 'Tomar com água, preferencialmente após as refeições. Não exceder a dose recomendada.',
        'Antibiótico': 'Tomar em horários regulares. Completar todo o tratamento mesmo que os sintomas melhorem.',
        'Anti-hipertensivo': 'Tomar sempre no mesmo horário. Não interromper o tratamento sem orientação médica.',
        'Antidepressivo': 'Pode levar algumas semanas para fazer efeito. Não interromper abruptamente.',
        'Anti-inflamatório': 'Tomar com alimentos para reduzir irritação gástrica. Evitar uso prolongado.',
        'Diurético': 'Tomar pela manhã para evitar noctúria. Manter hidratação adequada.',
        'Antidiabético': 'Tomar antes das refeições. Monitorar glicemia regularmente.',