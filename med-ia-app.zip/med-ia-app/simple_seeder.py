from src.models.user import db
from src.models.medication import Medication, Interaction
from src.models.disease import Disease
from src.models.health_facility import HealthFacility

def seed_sample_data():
    """Popula o banco com dados de exemplo para teste"""
    print("Populando dados de exemplo...")
    
    # Medicamentos de exemplo
    medications = [
        {
            'nome_comercial': 'Paracetamol',
            'principio_ativo': 'Paracetamol',
            'laboratorio': 'EMS',
            'categoria': 'Analgésico',
            'registro_anvisa': '123456789',
            'forma_farmaceutica': 'Comprimido',
            'dosagem': '500mg a cada 6 horas',
            'instrucoes': 'Tomar com água, preferencialmente após as refeições.'
        },
        {
            'nome_comercial': 'Dipirona',
            'principio_ativo': 'Dipirona Sódica',
            'laboratorio': 'Medley',
            'categoria': 'Analgésico',
            'registro_anvisa': '987654321',
            'forma_farmaceutica': 'Comprimido',
            'dosagem': '500mg a cada 8 horas',
            'instrucoes': 'Tomar com água. Não exceder 4 comprimidos por dia.'
        },
        {
            'nome_comercial': 'Losartana',
            'principio_ativo': 'Losartana Potássica',
            'laboratorio': 'Eurofarma',
            'categoria': 'Anti-hipertensivo',
            'registro_anvisa': '456789123',
            'forma_farmaceutica': 'Comprimido',
            'dosagem': '50mg uma vez ao dia',
            'instrucoes': 'Tomar sempre no mesmo horário, preferencialmente pela manhã.'
        },
        {
            'nome_comercial': 'Amoxicilina',
            'principio_ativo': 'Amoxicilina',
            'laboratorio': 'Neo Química',
            'categoria': 'Antibiótico',
            'registro_anvisa': '789123456',
            'forma_farmaceutica': 'Cápsula',
            'dosagem': '500mg a cada 8 horas',
            'instrucoes': 'Tomar em horários regulares. Completar todo o tratamento.'
        },
        {
            'nome_comercial': 'Omeprazol',
            'principio_ativo': 'Omeprazol',
            'laboratorio': 'Germed',
            'categoria': 'Inibidor de Bomba de Prótons',
            'registro_anvisa': '321654987',
            'forma_farmaceutica': 'Cápsula',
            'dosagem': '20mg uma vez ao dia',
            'instrucoes': 'Tomar em jejum, 30 minutos antes do café da manhã.'
        }
    ]
    
    med_objects = []
    for med_data in medications:
        existing = Medication.query.filter_by(nome_comercial=med_data['nome_comercial']).first()
        if not existing:
            med = Medication(**med_data)
            db.session.add(med)
            med_objects.append(med)
    
    db.session.commit()
    
    # Doenças de exemplo
    diseases = [
        {
            'cid_code': 'I10',
            'name': 'Hipertensão essencial (primária)',
            'treatment_info': 'Condição crônica que requer controle contínuo da pressão arterial',
            'recommended_treatment': 'Medicamentos anti-hipertensivos, dieta com baixo teor de sódio, exercícios regulares',
            'incapacitating_potential': 'potencialmente'
        },
        {
            'cid_code': 'E11',
            'name': 'Diabetes mellitus não-insulino-dependente',
            'treatment_info': 'Doença metabólica crônica que afeta o controle da glicose',
            'recommended_treatment': 'Medicamentos antidiabéticos, dieta controlada, exercícios, monitoramento da glicemia',
            'incapacitating_potential': 'potencialmente'
        },
        {
            'cid_code': 'J06.9',
            'name': 'Infecção aguda das vias aéreas superiores não especificada',
            'treatment_info': 'Infecção viral comum das vias respiratórias superiores',
            'recommended_treatment': 'Repouso, hidratação, analgésicos para sintomas, descongestionantes se necessário',
            'incapacitating_potential': 'não'
        },
        {
            'cid_code': 'K21',
            'name': 'Doença do refluxo gastroesofágico',
            'treatment_info': 'Condição onde o ácido do estômago retorna ao esôfago',
            'recommended_treatment': 'Inibidores de bomba de prótons, mudanças na dieta, elevação da cabeceira da cama',
            'incapacitating_potential': 'não'
        },
        {
            'cid_code': 'M79.3',
            'name': 'Paniculite não especificada',
            'treatment_info': 'Inflamação do tecido adiposo subcutâneo',
            'recommended_treatment': 'Anti-inflamatórios, repouso, compressas frias ou quentes conforme indicação',
            'incapacitating_potential': 'não'
        }
    ]
    
    for disease_data in diseases:
        existing = Disease.query.filter_by(cid_code=disease_data['cid_code']).first()
        if not existing:
            disease = Disease(**disease_data)
            db.session.add(disease)
    
    db.session.commit()
    
    # Interações de exemplo
    if len(med_objects) >= 2:
        interactions = [
            {
                'medication1_id': med_objects[0].id,  # Paracetamol
                'medication2_id': med_objects[1].id,  # Dipirona
                'severity': 'leve',
                'description': 'Uso concomitante pode aumentar o risco de efeitos adversos hepáticos.'
            }
        ]
        
        for interaction_data in interactions:
            existing = Interaction.query.filter_by(
                medication1_id=interaction_data['medication1_id'],
                medication2_id=interaction_data['medication2_id']
            ).first()
            if not existing:
                interaction = Interaction(**interaction_data)
                db.session.add(interaction)
    
    db.session.commit()
    print("Dados de exemplo populados com sucesso!")

if __name__ == '__main__':
    import sys
    import os
    sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
    
    from src.main import app
    with app.app_context():
        seed_sample_data()


    # Estabelecimentos de saúde de exemplo
    health_facilities = [
        {
            'name': 'UPA 24h Centro',
            'type': 'upa',
            'address': 'Rua das Flores, 123 - Centro, São Paulo - SP',
            'latitude': -23.5505,
            'longitude': -46.6333,
            'phone': '(11) 3456-7890',
            'services': 'Atendimento 24h, Emergência, Raio-X, Laboratório'
        },
        {
            'name': 'Hospital São Lucas',
            'type': 'hospital',
            'address': 'Av. Paulista, 1000 - Bela Vista, São Paulo - SP',
            'latitude': -23.5618,
            'longitude': -46.6565,
            'phone': '(11) 2345-6789',
            'services': 'Emergência, UTI, Cirurgias, Maternidade, Oncologia'
        },
        {
            'name': 'Posto de Saúde Vila Madalena',
            'type': 'posto de saúde',
            'address': 'Rua Harmonia, 456 - Vila Madalena, São Paulo - SP',
            'latitude': -23.5505,
            'longitude': -46.6914,
            'phone': '(11) 3123-4567',
            'services': 'Consultas básicas, Vacinação, Preventivo, Curativos'
        },
        {
            'name': 'Farmácia Popular Central',
            'type': 'farmácia',
            'address': 'Rua Augusta, 789 - Consolação, São Paulo - SP',
            'latitude': -23.5558,
            'longitude': -46.6396,
            'phone': '(11) 3987-6543',
            'services': 'Medicamentos, Programa Farmácia Popular, Teste de glicemia'
        },
        {
            'name': 'Drogaria São Paulo',
            'type': 'farmácia',
            'address': 'Av. Faria Lima, 321 - Itaim Bibi, São Paulo - SP',
            'latitude': -23.5781,
            'longitude': -46.6890,
            'phone': '(11) 3456-1234',
            'services': 'Medicamentos, Perfumaria, Conveniência, Entrega 24h'
        },
        {
            'name': 'Hospital Albert Einstein',
            'type': 'hospital',
            'address': 'Av. Albert Einstein, 627 - Morumbi, São Paulo - SP',
            'latitude': -23.5986,
            'longitude': -46.7180,
            'phone': '(11) 2151-1233',
            'services': 'Emergência, UTI, Cirurgias, Check-up, Medicina preventiva'
        },
        {
            'name': 'Pronto Socorro Municipal',
            'type': 'pronto socorro',
            'address': 'Rua da Consolação, 555 - Consolação, São Paulo - SP',
            'latitude': -23.5489,
            'longitude': -46.6388,
            'phone': '(11) 3258-7777',
            'services': 'Emergência 24h, Trauma, Clínica médica, Pediatria'
        },
        {
            'name': 'Farmácia Droga Raia',
            'type': 'farmácia',
            'address': 'Rua Oscar Freire, 987 - Jardins, São Paulo - SP',
            'latitude': -23.5614,
            'longitude': -46.6707,
            'phone': '(11) 3062-4444',
            'services': 'Medicamentos, Cosméticos, Manipulação, Delivery'
        }
    ]
    
    for facility_data in health_facilities:
        existing = HealthFacility.query.filter_by(name=facility_data['name']).first()
        if not existing:
            facility = HealthFacility(**facility_data)
            db.session.add(facility)
    
    db.session.commit()

