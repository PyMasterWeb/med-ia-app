from flask import Blueprint, request, jsonify
from src.models.medication import db, Medication, Interaction
from sqlalchemy import or_, func

medication_bp = Blueprint('medication', __name__)

@medication_bp.route('/medications/search', methods=['GET'])
def search_medications():
    """Buscar medicamentos por nome comercial ou princípio ativo com autocompletar"""
    try:
        query = request.args.get('q', '').strip()
        limit = request.args.get('limit', 20, type=int)
        
        if not query:
            return jsonify({
                'success': False,
                'error': 'Parâmetro de busca é obrigatório'
            }), 400
        
        # Buscar por nome comercial ou princípio ativo
        medications = Medication.query.filter(
            or_(
                Medication.nome_comercial.ilike(f'%{query}%'),
                Medication.principio_ativo.ilike(f'%{query}%')
            )
        ).limit(limit).all()
        
        return jsonify({
            'success': True,
            'medications': [med.to_dict() for med in medications],
            'query': query,
            'count': len(medications)
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@medication_bp.route('/medications/autocomplete', methods=['GET'])
def autocomplete_medications():
    """Autocompletar nomes de medicamentos"""
    try:
        query = request.args.get('q', '').strip()
        limit = request.args.get('limit', 10, type=int)
        
        if not query or len(query) < 2:
            return jsonify({
                'success': True,
                'suggestions': []
            })
        
        # Buscar sugestões de autocompletar
        suggestions = db.session.query(Medication.nome_comercial).filter(
            Medication.nome_comercial.ilike(f'{query}%')
        ).distinct().limit(limit).all()
        
        suggestion_list = [s[0] for s in suggestions]
        
        return jsonify({
            'success': True,
            'suggestions': suggestion_list,
            'query': query
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@medication_bp.route('/medications/<int:medication_id>', methods=['GET'])
def get_medication_details(medication_id):
    """Obter detalhes completos de um medicamento"""
    try:
        medication = Medication.query.get_or_404(medication_id)
        
        # Buscar interações
        interactions = Interaction.query.filter(
            or_(
                Interaction.medication1_id == medication_id,
                Interaction.medication2_id == medication_id
            )
        ).all()
        
        # Enriquecer interações com nomes dos medicamentos
        interactions_data = []
        for interaction in interactions:
            inter_dict = interaction.to_dict()
            med1 = Medication.query.get(interaction.medication1_id)
            med2 = Medication.query.get(interaction.medication2_id)
            inter_dict['medication1_name'] = med1.nome_comercial if med1 else 'Desconhecido'
            inter_dict['medication2_name'] = med2.nome_comercial if med2 else 'Desconhecido'
            interactions_data.append(inter_dict)
        
        medication_data = medication.to_dict()
        medication_data['interactions'] = interactions_data
        
        return jsonify({
            'success': True,
            'medication': medication_data
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@medication_bp.route('/medications/<int:medication_id>/interactions', methods=['GET'])
def get_medication_interactions(medication_id):
    """Obter interações de um medicamento específico"""
    try:
        medication = Medication.query.get_or_404(medication_id)
        
        # Buscar interações onde o medicamento aparece como med1 ou med2
        interactions = Interaction.query.filter(
            or_(
                Interaction.medication1_id == medication_id,
                Interaction.medication2_id == medication_id
            )
        ).all()
        
        # Enriquecer com nomes dos medicamentos
        interactions_data = []
        for interaction in interactions:
            inter_dict = interaction.to_dict()
            med1 = Medication.query.get(interaction.medication1_id)
            med2 = Medication.query.get(interaction.medication2_id)
            inter_dict['medication1_name'] = med1.nome_comercial if med1 else 'Desconhecido'
            inter_dict['medication2_name'] = med2.nome_comercial if med2 else 'Desconhecido'
            interactions_data.append(inter_dict)

        return jsonify({
            'success': True,
            'medication_id': medication_id,
            'medication_name': medication.nome_comercial,
            'interactions': interactions_data,
            'interaction_count': len(interactions_data)
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@medication_bp.route('/interactions/check', methods=['POST'])
def check_multiple_interactions():
    """Verificar interações entre múltiplos medicamentos"""
    try:
        data = request.get_json()
        medication_ids = data.get('medication_ids', [])
        
        if not medication_ids or len(medication_ids) < 2:
            return jsonify({
                'success': False,
                'error': 'Pelo menos 2 medicamentos são necessários'
            }), 400
        
        interactions = []
        
        # Verificar interações entre todos os pares de medicamentos
        for i in range(len(medication_ids)):
            for j in range(i + 1, len(medication_ids)):
                med1_id = medication_ids[i]
                med2_id = medication_ids[j]
                
                interaction = Interaction.query.filter(
                    or_(
                        (Interaction.medication1_id == med1_id) & (Interaction.medication2_id == med2_id),
                        (Interaction.medication1_id == med2_id) & (Interaction.medication2_id == med1_id)
                    )
                ).first()
                
                if interaction:
                    inter_dict = interaction.to_dict()
                    med1 = Medication.query.get(interaction.medication1_id)
                    med2 = Medication.query.get(interaction.medication2_id)
                    inter_dict['medication1_name'] = med1.nome_comercial if med1 else 'Desconhecido'
                    inter_dict['medication2_name'] = med2.nome_comercial if med2 else 'Desconhecido'
                    interactions.append(inter_dict)
        
        # Classificar por severidade
        severity_order = {'grave': 3, 'moderada': 2, 'leve': 1}
        interactions.sort(key=lambda x: severity_order.get(x['severity'], 0), reverse=True)
        
        return jsonify({
            'success': True,
            'medication_ids': medication_ids,
            'interactions': interactions,
            'has_interactions': len(interactions) > 0,
            'interaction_count': len(interactions)
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@medication_bp.route('/medications/by_disease', methods=['GET'])
def get_medications_by_disease():
    """Buscar medicamentos por doença/condição médica"""
    try:
        disease_query = request.args.get('disease', '').strip()
        
        if not disease_query:
            return jsonify({
                'success': False,
                'error': 'Parâmetro de doença é obrigatório'
            }), 400
        
        # Mapeamento simplificado de doenças para categorias de medicamentos
        disease_mapping = {
            'hipertensão': ['Anti-hipertensivo', 'Diurético'],
            'diabetes': ['Antidiabético Oral', 'Insulina'],
            'depressão': ['Antidepressivo'],
            'ansiedade': ['Antidepressivo', 'Ansiolítico'],
            'dor': ['Analgésico', 'Anti-inflamatório'],
            'infecção': ['Antibiótico', 'Antimicrobiano'],
            'colesterol': ['Hipolipemiante'],
            'refluxo': ['Inibidor de Bomba de Prótons'],
            'asma': ['Broncodilatador', 'Corticosteroide'],
            'enxaqueca': ['Analgésico', 'Triptano'],
            'artrite': ['Anti-inflamatório', 'Corticosteroide'],
            'epilepsia': ['Anticonvulsivante'],
            'parkinson': ['Antiparkinsiano'],
            'alzheimer': ['Anticolinesterásico'],
            'insônia': ['Hipnótico', 'Sedativo'],
            'alergia': ['Anti-histamínico', 'Corticosteroide'],
            'gripe': ['Antigripal', 'Analgésico'],
            'febre': ['Antitérmico', 'Analgésico'],
            'tosse': ['Antitussígeno', 'Expectorante'],
            'constipação': ['Laxante'],
            'diarreia': ['Antidiarreico'],
            'náusea': ['Antiemético'],
            'vertigem': ['Antivertiginoso'],
            'glaucoma': ['Anti-glaucomatoso'],
            'osteoporose': ['Bifosfonato', 'Cálcio'],
            'anemia': ['Antianêmico', 'Ferro'],
            'gota': ['Antigotoso'],
            'psoriase': ['Antipsoriásico'],
            'acne': ['Antiacneico'],
            'fungos': ['Antifúngico'],
            'vermes': ['Antiparasitário'],
            'malária': ['Antimalárico'],
            'tuberculose': ['Antituberculoso'],
            'hiv': ['Antirretroviral'],
            'hepatite': ['Antiviral'],
            'câncer': ['Antineoplásico', 'Quimioterápico'],
            'trombose': ['Anticoagulante'],
            'arritmia': ['Antiarrítmico'],
            'angina': ['Antianginoso'],
            'insuficiência cardíaca': ['Cardiotônico'],
            'hipotireoidismo': ['Hormônio da Tireoide'],
            'hipertireoidismo': ['Antitireoidiano'],
            'menopausa': ['Hormônio'],
            'contraceptivo': ['Contraceptivo'],
            'impotência': ['Vasodilatador'],
            'próstata': ['Alfa-bloqueador'],
            'cistite': ['Antibiótico', 'Antisséptico Urinário'],
            'rinite': ['Anti-histamínico', 'Descongestionante'],
            'sinusite': ['Antibiótico', 'Descongestionante'],
            'otite': ['Antibiótico', 'Anti-inflamatório'],
            'conjuntivite': ['Antibiótico Oftálmico'],
            'herpes': ['Antiviral'],
            'candidíase': ['Antifúngico'],
            'gastrite': ['Antiulceroso', 'Inibidor de Bomba de Prótons'],
            'úlcera': ['Antiulceroso', 'Inibidor de Bomba de Prótons'],
            'hemorroidas': ['Anti-hemorroidário'],
            'varizes': ['Venotônico'],
            'celulite': ['Antibiótico'],
            'queimadura': ['Cicatrizante'],
            'ferida': ['Cicatrizante', 'Antisséptico'],
            'picada': ['Anti-histamínico', 'Corticosteroide'],
            'ressaca': ['Analgésico', 'Antitérmico'],
            'stress': ['Ansiolítico', 'Fitoterápico'],
            'fadiga': ['Estimulante', 'Vitamina'],
            'memória': ['Nootrópico'],
            'concentração': ['Estimulante'],
            'libido': ['Estimulante Sexual'],
            'calvície': ['Anticalvície'],
            'estrias': ['Regenerador'],
            'rugas': ['Antienvelhecimento'],
            'manchas': ['Despigmentante'],
            'caspa': ['Anticaspa'],
            'seborreia': ['Antisseborreico'],
            'dermatite': ['Corticosteroide', 'Anti-inflamatório'],
            'eczema': ['Corticosteroide', 'Emoliente'],
            'urticária': ['Anti-histamínico', 'Corticosteroide'],
            'vitiligo': ['Repigmentante'],
            'melasma': ['Despigmentante'],
            'rosácea': ['Anti-inflamatório', 'Vasoconstritor'],
            'psoríase': ['Antipsoriásico', 'Corticosteroide'],
            'escabiose': ['Escabicida'],
            'pediculose': ['Pediculicida'],
            'micose': ['Antifúngico'],
            'frieira': ['Antifúngico'],
            'unha encravada': ['Anti-inflamatório', 'Antibiótico'],
            'calos': ['Queratolítico'],
            'verrugas': ['Verrucida'],
            'molusco': ['Imunomodulador'],
            'herpes zoster': ['Antiviral', 'Analgésico'],
            'catapora': ['Antiviral', 'Anti-histamínico'],
            'sarampo': ['Antiviral', 'Antitérmico'],
            'rubéola': ['Antiviral', 'Antitérmico'],
            'caxumba': ['Antiviral', 'Anti-inflamatório'],
            'coqueluche': ['Antibiótico', 'Antitussígeno'],
            'meningite': ['Antibiótico', 'Corticosteroide'],
            'pneumonia': ['Antibiótico', 'Broncodilatador'],
            'bronquite': ['Broncodilatador', 'Expectorante'],
            'enfisema': ['Broncodilatador', 'Corticosteroide'],
            'fibrose': ['Antifibrótico'],
            'embolia': ['Anticoagulante', 'Trombolítico'],
            'infarto': ['Anticoagulante', 'Betabloqueador'],
            'avc': ['Anticoagulante', 'Neuroprotetor'],
            'convulsão': ['Anticonvulsivante'],
            'tremor': ['Antiparkinsoniano'],
            'espasmo': ['Relaxante Muscular'],
            'câimbra': ['Relaxante Muscular', 'Magnésio'],
            'tendinite': ['Anti-inflamatório', 'Analgésico'],
            'bursite': ['Anti-inflamatório', 'Corticosteroide'],
            'artrose': ['Anti-inflamatório', 'Condroprotetor'],
            'fibromialgia': ['Analgésico', 'Relaxante Muscular'],
            'lombalgia': ['Analgésico', 'Relaxante Muscular'],
            'ciática': ['Analgésico', 'Anti-inflamatório'],
            'hérnia': ['Analgésico', 'Relaxante Muscular'],
            'torcicolo': ['Relaxante Muscular', 'Analgésico'],
            'luxação': ['Analgésico', 'Anti-inflamatório'],
            'fratura': ['Analgésico', 'Cálcio'],
            'entorse': ['Anti-inflamatório', 'Analgésico'],
            'contusão': ['Anti-inflamatório', 'Analgésico'],
            'hematoma': ['Anti-inflamatório', 'Vasoconstritor'],
            'edema': ['Diurético', 'Venotônico'],
            'retenção': ['Diurético'],
            'inchaço': ['Diurético', 'Anti-inflamatório']
        }
        
        # Buscar categorias correspondentes
        categories = []
        disease_lower = disease_query.lower()
        
        for disease, cats in disease_mapping.items():
            if disease in disease_lower or disease_lower in disease:
                categories.extend(cats)
        
        if not categories:
            # Se não encontrar mapeamento específico, buscar por nome na categoria
            medications = Medication.query.filter(
                or_(
                    Medication.categoria.ilike(f'%{disease_query}%'),
                    Medication.nome_comercial.ilike(f'%{disease_query}%'),
                    Medication.principio_ativo.ilike(f'%{disease_query}%')
                )
            ).limit(20).all()
        else:
            # Buscar medicamentos das categorias encontradas
            category_filters = [Medication.categoria.ilike(f'%{cat}%') for cat in categories]
            medications = Medication.query.filter(
                or_(*category_filters)
            ).limit(20).all()
        
        return jsonify({
            'success': True,
            'disease': disease_query,
            'categories': categories,
            'medications': [med.to_dict() for med in medications],
            'count': len(medications)
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

